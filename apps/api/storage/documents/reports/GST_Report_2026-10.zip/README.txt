========================================================================
ANKITA PROCESSORS — MONTHLY GST REPORT ARCHIVE
Reporting Period: 2026-10 (October 2026)
Generated At: 2026-10-21 17:24:47 IST
Seller GSTIN: 24ANCPN9292N2ZB | Legal Name: Ankita Processors
========================================================================

ARCHIVE CONTENTS:
1. monthly_gst_summary.csv - High level executive totals & tax components
2. monthly_gst_summary.json - Structured metadata payload
3. tax_rate_breakdown.csv - HSN/Rate-wise taxable value, CGST, SGST, IGST
4. sales_register.csv - Complete itemized sales ledger for the period
5. reconciliation_audit.csv - Anomaly and reconciliation discrepancy analysis

KEY FIGURES:
• Gross Sales Turnover: ₹5250.00
• Total Taxable Value:  ₹5000.00
• Central Tax (CGST):  ₹125.00
• State Tax (SGST):    ₹125.00
• Integrated Tax (IGST): ₹0.00
• Total Tax Liability: ₹250.00
• Total Invoices:      1 (B2B: 0, B2C: 1)
========================================================================