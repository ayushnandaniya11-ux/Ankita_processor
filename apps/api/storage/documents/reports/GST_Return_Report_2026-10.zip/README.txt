========================================================================
ANKITA PROCESSORS — GST RETURN PREPARATION REPORT (GSTR-1 & GSTR-3B)
Tax Period: 2026-10 | Financial Year: 2026-2027
Generated: 2026-10-21 17:24:47 IST
========================================================================

IMPORTANT COMPLIANCE NOTICE:
These working papers are prepared strictly for filing preparation of GSTR-1
and GSTR-3B according to CBIC guidelines. This file DOES NOT constitute an
official confirmation of return filing with the GST Common Portal (GSTN).
Verify numbers against accounting ledgers prior to submission.

ARCHIVE CONTENTS:
1. gstr1_b2b.csv - Section 4: Taxable outward supplies to registered persons
2. gstr1_b2b.json - Government JSON schema format for GSTR-1 B2B upload
3. gstr1_b2cs.csv - Section 7: Taxable outward supplies to unregistered persons
4. gstr1_hsn_summary.csv - Section 12: HSN-wise summary of outward supplies
5. gstr1_doc_issue.csv - Section 13: Documents issued during the tax period
6. gstr3b_table3_1.csv - Table 3.1 details of outward supplies & tax liability
7. gstr3b_working_paper.json - Complete working paper data
========================================================================