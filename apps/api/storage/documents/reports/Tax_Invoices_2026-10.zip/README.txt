========================================================================
ANKITA PROCESSORS — MONTHLY TAX INVOICE ARCHIVE
Reporting Period: 2026-10 (October 2026)
Generated: 2026-10-21 17:24:47 IST
Total PDF Invoices Included: 1
========================================================================

CONTENTS:
• invoice_register.csv - Complete metadata register of all issued invoices
• invoices/ - Directory containing the official PDF tax invoices for each order
• credit_notes/ - Directory containing credit notes (if applicable)

All PDF documents comply with Section 31 of the CGST Act, 2017 and are digitally preserved.
========================================================================